<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2bc62491774773d01f5442f587e9f30d',
      'native_key' => 'rapidhtml2png',
      'filename' => 'modNamespace/8681478831005f9cb871fe38bfbe7912.vehicle',
      'namespace' => 'rapidhtml2png',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd60dcfd6172c071bdd7afa024bf178f2',
      'native_key' => 'rapidhtml2png',
      'filename' => 'modNamespace/f1bb572d123b8ecb638f61814018cb60.vehicle',
      'namespace' => 'rapidhtml2png',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9d8b46987d81eea9c964592a630d743',
      'native_key' => 'rapidhtml2png_convert_url',
      'filename' => 'modSystemSetting/ac36e4d081dda8ddd702b5cc2df1cb73.vehicle',
      'namespace' => 'rapidhtml2png',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e7be17ed7510debe22b91f095692a90',
      'native_key' => 'rapidhtml2png_convert_api_key',
      'filename' => 'modSystemSetting/b3232f2a440e7d226f2e1e70cd6466d3.vehicle',
      'namespace' => 'rapidhtml2png',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4eccced811050de1f7a17014e9d9feff',
      'native_key' => 'rapidhtml2png_css_url',
      'filename' => 'modSystemSetting/ffe812e8d3c6b1f3cd6df2a4abd71bd1.vehicle',
      'namespace' => 'rapidhtml2png',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7dcd539bfda5c76383e5e313ef21d3c0',
      'native_key' => 'rapidhtml2png_render_engine',
      'filename' => 'modSystemSetting/18af7d1c0f5223cc75aeb47cc9770721.vehicle',
      'namespace' => 'rapidhtml2png',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c10158a2103038e279a8860162208247',
      'native_key' => 'rapidhtml2png_request_timeout',
      'filename' => 'modSystemSetting/e12fca0b13872a18297a77e3b1a9c263.vehicle',
      'namespace' => 'rapidhtml2png',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2e9264452a42647c96223fc0711c61b',
      'native_key' => 'rapidhtml2png_batch_max_bytes',
      'filename' => 'modSystemSetting/5c60a69d7156fd6ce17842cb8fe9a2b9.vehicle',
      'namespace' => 'rapidhtml2png',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53c1c795e2331b87adc5a220468aac61',
      'native_key' => 'rapidhtml2png_batch_max_blocks',
      'filename' => 'modSystemSetting/97741f757628ea135ca7320d971864cb.vehicle',
      'namespace' => 'rapidhtml2png',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67f8afe3b5b4eb7c6609e5a902d18935',
      'native_key' => 'rapidhtml2png_default_skip_classes',
      'filename' => 'modSystemSetting/a1767eb676f3bdd94fe611a11e82e7b0.vehicle',
      'namespace' => 'rapidhtml2png',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '45f8b4eae4873ade95fb99661f03dbd4',
      'native_key' => NULL,
      'filename' => 'modCategory/31036af333ae15f623e361a1d3b7bd96.vehicle',
      'namespace' => 'rapidhtml2png',
    ),
  ),
);